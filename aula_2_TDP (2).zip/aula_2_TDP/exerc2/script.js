function ordenarNumeros() {


    let numero1 = parseInt(document.getElementById("numero1").value);
    let numero2 = parseInt(document.getElementById("numero2").value);
    let numero3 = parseInt(document.getElementById("numero3").value);
    let numero4 = parseInt(document.getElementById("numero4").value);
    let numero5 = parseInt(document.getElementById("numero5").value);


    let numeros = [numero1, numero2, numero3, numero4, numero5];


    numeros.sort(function(a, b) {
        return b - a;
    });

    let resultado = "Números em ordem decrescente: " + numeros.join(", ");

    document.getElementById("resultado").innerText = resultado;
}

