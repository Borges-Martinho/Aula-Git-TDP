let numero = prompt("Por favor, insira um número:");

if (!isNaN(numero)) {
    
    numero = parseInt(numero);
    
    if (numero % 2 === 0) {
        console.log("O número inserido é PAR.");
    } else {
        console.log("O número inserido é ÍMPAR.");
    }
} else {
    console.log("Por favor, insira um número válido.");
}