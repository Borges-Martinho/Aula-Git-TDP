document.getElementById("calcularButton").addEventListener("click", function() {
    var altura = parseFloat(document.getElementById("altura").value);
    var peso = parseFloat(document.getElementById("peso").value);

    if (altura && peso) {
        var imc = peso / (altura * altura);

        var resultado = "Seu IMC é: " + imc.toFixed(2); // Arredondando para duas casas decimais
        document.getElementById("resultado").innerText = resultado;
    } else {
        document.getElementById("resultado").innerText = "Por favor, insira altura e peso válidos.";
    }
});
