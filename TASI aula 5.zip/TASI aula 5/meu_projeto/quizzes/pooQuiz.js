const express = require('express');
const router = express.Router();

const questions = [
    {
        question: 'O que é encapsulamento na Programação Orientada a Objetos?',
        options: ['Agrupamento de dados em uma única unidade', 'Extensão de uma classe', 'Acesso a dados diretamente'],
        answer: 'Agrupamento de dados em uma única unidade'
    },
    {
        question: 'Qual é o conceito de herança na POO?',
        options: ['Capacidade de um objeto se comportar de formas diferentes', 'Atribuir valores a variáveis', 'Reutilização de atributos e métodos de uma classe pai'],
        answer: 'Reutilização de atributos e métodos de uma classe pai'
    },
    {
        question: 'O que é polimorfismo na Programação Orientada a Objetos?',
        options: ['Capacidade de um objeto se comportar de formas diferentes', 'Atribuir valores a variáveis', 'Reutilização de atributos e métodos de uma classe pai'],
        answer: 'Capacidade de um objeto se comportar de formas diferentes'
    }
];

router.get('/', (req, res) => {
    res.json(questions);
});

module.exports = router;
