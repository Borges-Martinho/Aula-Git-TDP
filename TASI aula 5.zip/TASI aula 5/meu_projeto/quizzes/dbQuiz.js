const express = require('express');
const router = express.Router();

const questions = [
    {
        question: 'O que é um banco de dados relacional?',
        options: ['Tipo de banco de dados que organiza dados em tabelas relacionadas', 'Tipo de banco de dados que organiza dados em documentos', 'Tipo de banco de dados que organiza dados em registros'],
        answer: 'Tipo de banco de dados que organiza dados em tabelas relacionadas'
    },
    {
        question: 'Qual é a diferença entre as cláusulas SQL WHERE e HAVING?',
        options: ['WHERE filtra registros antes do agrupamento, HAVING filtra após o agrupamento', 'HAVING filtra registros antes do agrupamento, WHERE filtra após o agrupamento', 'Ambas funcionam da mesma forma'],
        answer: 'WHERE filtra registros antes do agrupamento, HAVING filtra após o agrupamento'
    },
    {
        question: 'O que é uma chave estrangeira em um banco de dados relacional?',
        options: ['Campo que se refere à chave primária de outra tabela', 'Campo que se refere à chave secundária de outra tabela', 'Campo que se refere à chave primária da mesma tabela'],
        answer: 'Campo que se refere à chave primária de outra tabela'
    }
];

router.get('/', (req, res) => {
    res.json(questions);
});

module.exports = router;
