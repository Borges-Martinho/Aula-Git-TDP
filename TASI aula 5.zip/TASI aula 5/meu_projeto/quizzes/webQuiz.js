const express = require('express');
const router = express.Router();

const questions = [
    {
        question: 'Qual é a diferença entre margin e padding em CSS?',
        options: ['Margin é espaço interno, padding é espaço externo', 'Margin é espaço externo, padding é espaço interno', 'Margin e padding funcionam da mesma forma'],
        answer: 'Margin é espaço externo, padding é espaço interno'
    },
    {
        question: 'O que é o modelo de caixa em CSS?',
        options: ['Representação visual de como o espaço é distribuído em torno de um elemento HTML', 'Forma como os elementos HTML são organizados', 'Forma como os elementos HTML são posicionados'],
        answer: 'Representação visual de como o espaço é distribuído em torno de um elemento HTML'
    },
    {
        question: 'Qual é a diferença entre == e === em JavaScript?',
        options: ['== verifica apenas o valor, === verifica o valor e o tipo de dados', '== verifica o valor e o tipo de dados, === verifica apenas o valor', '== e === funcionam da mesma forma'],
        answer: '== verifica apenas o valor, === verifica o valor e o tipo de dados'
    }
];

router.get('/', (req, res) => {
    res.json(questions);
});

module.exports = router;
