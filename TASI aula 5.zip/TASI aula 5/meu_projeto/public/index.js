const express = require('express');
const app = express();

// Configuração para servir arquivos estáticos
app.use(express.static('public'));

// Importa e configura os módulos de perguntas e respostas
const pooQuiz = require('./quizzes/pooQuiz');
const dbQuiz = require('./quizzes/dbQuiz');
const webQuiz = require('./quizzes/webQuiz');
app.use('/poo-quiz', pooQuiz);
app.use('/db-quiz', dbQuiz);
app.use('/web-quiz', webQuiz);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
